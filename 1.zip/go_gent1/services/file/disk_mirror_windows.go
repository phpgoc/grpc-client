package file

import pb "go-agent/agent_proto"

func platformDiskMirror(req *pb.DiskMirrorRequest, resStream pb.FileService_DiskMirrorServer) error {
	return nil
}
