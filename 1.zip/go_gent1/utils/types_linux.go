package utils

const LineBreak = "\n"
