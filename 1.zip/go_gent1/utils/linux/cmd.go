//go:build linux

package linux

// timeout if 0 then wait forever
