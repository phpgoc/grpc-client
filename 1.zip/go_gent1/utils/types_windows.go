package utils

const LineBreak = "\r\n"
